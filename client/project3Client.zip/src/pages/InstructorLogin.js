import React from "react";
import InstructorForm from "../components/loginForm"

function Form(){
    return(
        <div>
            <InstructorForm />
        </div>
    )
}

export default Form;