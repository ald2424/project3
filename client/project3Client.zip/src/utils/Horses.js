import Moses from "../assets/images/Moses.jpg"
import shadrach from "../assets/images/Shadrach.jpg"
import jabez from "../assets/images/Jabez.jpg"
import naomi from "../assets/images/Naomi.jpg"
import ruth from "../assets/images/Ruth.jpg"
import mercy from "../assets/images/Mercy.jpg"
import Esther from "../assets/images/Esther.jpg"
import Boaz from "../assets/images/Boaz.jpg"
import Lucas from "../assets/images/Lucas.jpg"
import Selah from "../assets/images/Selah.jpg"
import Slater from "../assets/images/Slater.jpg"
import Levi from "../assets/images/Levi.jpg"
const horses = [
    {
        "name" : "Moses",
        "image" : Moses
    },
    {
        "name" : "Shadrach",
        "image" : shadrach
    },
    {
        "name" : "Jabez",
        "image" : jabez
    },
    {
        "name" : "Naomi",
        "image" : naomi
    },
    {
        "name" : "Ruth",
        "image" : ruth
    },
    {
        "name" : "Mercy",
        "image" : mercy
    },
    {
        "name" : "Esther",
        "image": Esther
    },
    {
        "name": "Boaz",
        "image": Boaz
    },
    {
        "name": "Lucas",
        "image": Lucas
    },
    {
        "name": "Selah",
        "image": Selah
    },
    {
        "name": "Levi",
        "image": Levi
    },
    {
        "name": "Slater",
        "image": Slater
    },
]

export default horses;