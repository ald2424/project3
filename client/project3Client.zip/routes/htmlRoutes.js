import loginForm from "./containers/loginForm";

<Route path="/login" exact component={loginForm} />